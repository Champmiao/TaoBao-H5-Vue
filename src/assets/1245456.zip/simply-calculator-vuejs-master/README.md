# vue-webpack-calculator

> 用vue.js实现简易计算器<br>
>A simply vue-calculator built by vue2.0 + vue-cli (webpack- simple) ,<br> fast way to get through vue.js , vue-loader and webpack .
<br>

Grade that this demo has been merged into the project :<a href="https://github.com/vuejs/awesome-vue">awesome-vue</a>:yum:<br>
And here is another vue demo <a href="https://github.com/CaiYiLiang/vue-demos/tree/master/wikipediaViewer-vuejs">wikipediaViewer-vuejs</a> ,which is also merged into the project :<a href="https://github.com/vuejs/awesome-vue">awesome-vue</a>:yum:


# demo
<img src="./calculator_vuejs.gif" alt="calculator.vuejs-demo" width="360px" height="auto">
<br>

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build
```
For detailed explanation on how things work, consult the [docs for vue-loader](http://vuejs.github.io/vue-loader).
<br>

## todo item
- add keycode eventListener
<br>

ヾ(o◕∀◕)ﾉヾ 如果有那么一丁点儿喜欢 请随手🌟~(≧▽≦)/~啦啦啦 <br>
ヾ(o◕∀◕)ﾉヾ Encourage me a start🌟 if you like itヾ(o◕∀◕)ﾉヾ 
